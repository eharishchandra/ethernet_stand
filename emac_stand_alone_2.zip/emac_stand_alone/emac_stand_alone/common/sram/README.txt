This common/ verilog is used by following designs:
   - design/ip/dmc1/src/
   - design/ip/dmc1c/src/
