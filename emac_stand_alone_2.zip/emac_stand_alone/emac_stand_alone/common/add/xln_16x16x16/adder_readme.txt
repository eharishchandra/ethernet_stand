The following files were generated for 'adder' in directory 
C:\Xilinx92i\bin\nt\adder\:

adder.ngc:
   Binary Xilinx implementation netlist file containing the information
   required to implement the module in a Xilinx (R) FPGA.

adder.v:
   Verilog wrapper file provided to support functional simulation.
   This file contains simulation model customization data that is
   passed to a parameterized simulation model for the core.

adder.veo:
   VEO template file containing code that can be used as a model for
   instantiating a CORE Generator module in a Verilog design.

adder.xco:
   CORE Generator input file containing the parameters used to
   regenerate a core.

adder_flist.txt:
   Text file listing all of the output files produced when a customized
   core was generated in the CORE Generator.

adder_padded.edn:
   EDIF wrapper file generated for a core when the Generate netlist
   wrapper with IO pads project option is enabled. The file adds input
   pads and output pads to the core, allowing you to process the
   generated core through the Xilinx design flow as if it were a
   complete chip design.

adder_readme.txt:
   Text file indicating the files generated and how they are used.

adder_xmdf.tcl:
   Please see the core data sheet.


Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

