Regmaster contains avalon slave register interface and the syncronizers.
One interface is avalon bus interface and the other interface is the reg bus interface.